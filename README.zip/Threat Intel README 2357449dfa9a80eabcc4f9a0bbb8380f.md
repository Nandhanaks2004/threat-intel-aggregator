# Threat Intel README

# Threat Intelligence Aggregator

## Description

**Threat Intelligence Aggregator** is a Python-driven dashboard that brings together real-time threat intelligence from **VirusTotal, Shodan, and AbuseIPDB** into a single platform. It allows security teams and analysts to rapidly assess the risk level of various IOCs (Indicators of Compromise) such as **IP addresses, domains, URLs, and file hashes**. By integrating multiple established open threat intelligence sources, the tool helps identify, prioritize, and report cyber threats efficiently.

## Features

- **Multi-Source Lookup:** Scan **IP addresses, domains, URLs, or file hashes** across VirusTotal, Shodan, and AbuseIPDB APIs.
- **Automated Risk Assessment:** Each IOC is automatically assessed and categorized as *High*, *Medium*, *Low*, or *Legitimate* risk based on intelligence data.
- **Batch Scanning:** Quickly process large lists by uploading CSV files of IOCs for automated scanning and enrichment.
- **Interactive Dashboard:** Visualize findings, trends, and summaries through an intuitive Streamlit web dashboard.
- **Report Generation:** Export comprehensive PDF reports of scan results for sharing and documentation.
- **API Key Management:** Secure interface to input and manage your API keys easily from within the dashboard.
- **Support & Contact:** Built-in section for reaching out if help or feedback is needed.

## Technologies Used

- **Python 3.8+** – Core programming language
- **Streamlit** – For building interactive web dashboards
- **pandas** – Data handling and manipulation
- **requests** – HTTP calls to external threat APIs
- **plotly** – Visualization and charts
- **fpdf** – PDF report generation
- **shodan** – Accessing the Shodan threat intelligence database
- **virustotal-python** – VirusTotal API integration
- **AbuseIPDB API (via requests)** – IP reputation lookups
- **CSV** – Bulk data import/export

## Setup Instructions

1. **Clone the repository:**
    
    `bashgit clone https://github.com/yourusername/threat-intel-aggregator.git
    cd threat-intel-aggregator`
    
2. **Install dependencies:**
    
    `bashpip install -r requirements.txt`
    
3. **Run the app:**
    
    `bashstreamlit run streamlit_app.py`
    
4. **Configure API Keys:**
    
    Go to the **Settings** section of the app's dashboard and add your VirusTotal, Shodan, and AbuseIPDB API keys.
    

## How to Use

- **Single Scan:** Enter an IP, domain, URL, or file hash into the scan form for immediate threat analysis across all integrated platforms.
- **Batch/CSV Scan:** Upload a **`.csv`** file containing a list of IOCs (IPs, domains, URLs, hashes) for mass processing. Results will be automatically categorized and displayed.
- **Dashboard Visualization:** Review threats, trends, and flagged items interactively. Apply filters to focus on timeframes, threat types, or individual IOCs (similar to professional SOC dashboards).
- **PDF Reporting:** After scanning, export results to a well-formatted PDF report for sharing (email option) or compliance.
- **Settings:** Update your API credentials at any time within the app.

## Screenshots

- The login page :

![Screenshot 2025-07-19 154859.png](Screenshot_2025-07-19_154859.png)

- The dashboard main view :

![image.png](image.png)

- Example scan results :
- manual IOC Scan :

![image.png](image%201.png)

- Batch scan:

![image.png](image%202.png)

- Results with more details:

![image.png](image%203.png)

- Scan History:

![image.png](image%204.png)

- PDF report sample (Download option):

![image.png](image%205.png)

- **Live Demo:**